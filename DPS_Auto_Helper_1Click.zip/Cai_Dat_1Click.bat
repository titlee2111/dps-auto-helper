@echo off
title Cai Dat DPS Auto Helper (1-Click)
cls
echo ============================================================
echo   DPS AUTO HELPER - CAI DAT 1-CLICK TU DONG
echo ============================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
pause

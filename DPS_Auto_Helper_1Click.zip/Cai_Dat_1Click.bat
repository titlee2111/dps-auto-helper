@echo off
setlocal enabledelayedexpansion
title Cai Dat DPS Auto Helper (1-Click)
cls
echo ============================================================
echo   DPS AUTO HELPER - CAI DAT 1-CLICK TU DONG
echo ============================================================
echo.

set "GAME_DIR="

:: 1. Check if bat is run directly inside game folder
if exist "%~dp0DPS.exe" if exist "%~dp0GameAssembly.dll" (
    set "GAME_DIR=%~dp0"
    goto :FoundGame
)

:: 2. Check if bat is in a subfolder inside game folder
if exist "%~dp0..\DPS.exe" if exist "%~dp0..\GameAssembly.dll" (
    set "GAME_DIR=%~dp0.."
    goto :FoundGame
)

:: 3. Check Steam registry HKCU
for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Valve\Steam" /v "SteamPath" 2^>nul') do (
    set "STEAMPATH=%%b"
)

:: If not in HKCU, check HKLM 64-bit
if not defined STEAMPATH (
    for /f "tokens=2*" %%a in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v "InstallPath" 2^>nul') do (
        set "STEAMPATH=%%b"
    )
)

if defined STEAMPATH (
    set "STEAMPATH=!STEAMPATH:/=\!"
    if exist "!STEAMPATH!\steamapps\common\DPS Desktop Pension Squad\DPS.exe" (
        set "GAME_DIR=!STEAMPATH!\steamapps\common\DPS Desktop Pension Squad"
        goto :FoundGame
    )
    if exist "!STEAMPATH!\steamapps\libraryfolders.vdf" (
        for /f "tokens=1,2 delims=	" %%i in ('findstr /i "\"path\"" "!STEAMPATH!\steamapps\libraryfolders.vdf" 2^>nul') do (
            set "LIBPATH=%%j"
            set "LIBPATH=!LIBPATH:"=!"
            set "LIBPATH=!LIBPATH:\\=\!"
            if exist "!LIBPATH!\steamapps\common\DPS Desktop Pension Squad\DPS.exe" (
                set "GAME_DIR=!LIBPATH!\steamapps\common\DPS Desktop Pension Squad"
                goto :FoundGame
            )
        )
    )
)

:: 4. Check common drives
for %%d in (C D E F G H) do (
    if not defined GAME_DIR (
        if exist "%%d:\SteamLibrary\steamapps\common\DPS Desktop Pension Squad\DPS.exe" (
            set "GAME_DIR=%%d:\SteamLibrary\steamapps\common\DPS Desktop Pension Squad"
            goto :FoundGame
        )
        if exist "%%d:\Program Files (x86)\Steam\steamapps\common\DPS Desktop Pension Squad\DPS.exe" (
            set "GAME_DIR=%%d:\Program Files (x86)\Steam\steamapps\common\DPS Desktop Pension Squad"
            goto :FoundGame
        )
        if exist "%%d:\Steam\steamapps\common\DPS Desktop Pension Squad\DPS.exe" (
            set "GAME_DIR=%%d:\Steam\steamapps\common\DPS Desktop Pension Squad"
            goto :FoundGame
        )
    )
)

:PromptUser
if not defined GAME_DIR (
    echo [!] Khong tim thay thu muc game Steam tu dong.
    echo.
    set /p "GAME_DIR=Vui long dan duong dan thu muc chua DPS.exe vao day: "
    set "GAME_DIR=!GAME_DIR:"=!"
    if not exist "!GAME_DIR!\DPS.exe" (
        echo.
        echo [LOI] Duong dan khong hop le! Khong tim thay file DPS.exe.
        echo.
        pause
        exit /b 1
    )
)

:FoundGame
echo [+] Da tim thay thu muc game:
echo     "!GAME_DIR!"
echo.

:: Check payload folder
if not exist "%~dp0payload" (
    echo [LOI] Khong tim thay thu muc 'payload'!
    echo Vui long giai nen toan bo file ZIP truoc khi chay Cai_Dat_1Click.bat.
    echo.
    pause
    exit /b 1
)

:: Check if game is running and close it safely
tasklist /fi "imagename eq DPS.exe" 2>nul | findstr /i "DPS.exe" >nul
if not errorlevel 1 (
    echo [!] Game DPS dang chay. Dang tat game de cap nhat file mod...
    taskkill /f /im DPS.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
)

:: Copy payload files into game folder
echo [+] Dang sao chep cac file mod vao thu muc game...
xcopy "%~dp0payload\*" "!GAME_DIR!\" /E /I /Y /Q >nul

if errorlevel 1 (
    echo [LOI] Co loi xay ra khi sao chep file!
    echo Vui long thu chay bang quyen Administrator hoac kiem tra dung luong o cung.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   CAI DAT THANH CONG DPS AUTO HELPER!
echo ============================================================
echo.
echo CAC BUOC TIEP THEO:
echo   1. Mo game DPS Desktop Pension Squad tren Steam.
echo   2. Mo trinh duyet va truy cap link giao dien sau de dieu khien:
echo      https://titlee2111.github.io/dps-auto-helper/
echo   3. Phim tat trong game: F6 (Tu Dong Cat Do), F7 (Tu Dong Hop Thanh).
echo.
pause

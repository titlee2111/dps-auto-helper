@echo off
chcp 65001 >nul
title Gỡ Cài Đặt DPS Auto Helper
cls
echo ============================================================
echo   GỠ CÀI ĐẶT DPS AUTO HELPER
echo ============================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "
$game = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not (Test-Path (Join-Path $game 'DPS.exe'))) {
    $game = 'G:\SteamLibrary\steamapps\common\DPS Desktop Pension Squad'
}
if (Test-Path (Join-Path $game 'winhttp.dll')) { Remove-Item (Join-Path $game 'winhttp.dll') -Force; Write-Host 'Đã xóa winhttp.dll' -ForegroundColor Yellow }
if (Test-Path (Join-Path $game 'doorstop_config.ini')) { Remove-Item (Join-Path $game 'doorstop_config.ini') -Force }
if (Test-Path (Join-Path $game 'BepInEx')) { Remove-Item (Join-Path $game 'BepInEx') -Recurse -Force; Write-Host 'Đã xóa thư mục BepInEx' -ForegroundColor Yellow }
Write-Host 'ĐÃ GỠ HOÀN TOÀN MOD! Game đã trở về nguyên bản.' -ForegroundColor Green
"
echo.
pause

@echo off
title DPS Auto Helper - Giao Dien Web
echo ============================================================
echo   DANG MO BANG DIEU KHIEN DPS AUTO HELPER TREN WEB...
echo ============================================================
echo.
echo Dia chi: http://127.0.0.1:47900/
start http://127.0.0.1:47900/
timeout /t 2 >nul
exit

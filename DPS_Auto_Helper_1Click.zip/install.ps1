<#
  DPS Auto Helper - 1-Click Installer
  100% Pure ASCII script to guarantee 0% syntax errors across all Windows language locales
#>
$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $root "payload"

if (-not (Test-Path $payload)) {
    Write-Host "[LOI] Khong tim thay thu muc payload! Hay giai nen toan bo file zip truoc." -ForegroundColor Red
    exit 1
}

function Test-GameFolder([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $false }
    return (Test-Path (Join-Path $path "DPS.exe")) -and (Test-Path (Join-Path $path "GameAssembly.dll"))
}

function Find-SteamLibraries {
    $libraries = New-Object System.Collections.Generic.List[string]
    $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { $steam = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -ErrorAction SilentlyContinue).InstallPath }

    if ($steam -and (Test-Path $steam)) {
        $libraries.Add($steam)
        $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($line in Get-Content $vdf) {
                if ($line -match '"path"\s+"([^"]+)"') {
                    $cand = $matches[1] -replace '\\\\', '\'
                    if (Test-Path $cand) { $libraries.Add($cand) }
                }
            }
        }
    }
    return $libraries | Select-Object -Unique
}

function Find-Game {
    if (Test-GameFolder $root) { return $root }
    $parent = Split-Path -Parent $root
    if (Test-GameFolder $parent) { return $parent }

    foreach ($library in Find-SteamLibraries) {
        $candidate = Join-Path $library "steamapps\common\DPS Desktop Pension Squad"
        if (Test-GameFolder $candidate) { return $candidate }
    }
    return $null
}

$GamePath = Find-Game
if (-not $GamePath) {
    Write-Host "[!] Khong tim thay thu muc cai game tu dong." -ForegroundColor Yellow
    $GamePath = Read-Host "Vui long dan duong dan thu muc chua DPS.exe vao day"
    if (-not (Test-GameFolder $GamePath)) {
        Write-Host "[LOI] Thu muc khong hop le! Khong tim thay DPS.exe va GameAssembly.dll." -ForegroundColor Red
        exit 1
    }
}

Write-Host "[+] Da tim thay game tai: " -NoNewline
Write-Host "$GamePath" -ForegroundColor Cyan

# Kiem tra neu game dang chay
$running = Get-Process "DPS" -ErrorAction SilentlyContinue
if ($running) {
    Write-Host "[!] Phat hien game DPS dang chay. Dang dong game de cap nhat file..." -ForegroundColor Yellow
    Stop-Process -Name "DPS" -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
}

# Sao chep payload
Write-Host "[+] Dang cai dat cac file mod vao thu muc game..." -ForegroundColor Green
$copied = 0
function Copy-Tree([string]$src, [string]$dst) {
    if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst -Force | Out-Null }
    foreach ($item in Get-ChildItem $src -Force) {
        $target = Join-Path $dst $item.Name
        if ($item.PSIsContainer) {
            Copy-Tree $item.FullName $target
        } else {
            Copy-Item $item.FullName $target -Force
            $script:copied++
        }
    }
}

Copy-Tree $payload $GamePath

Write-Host "============================================================" -ForegroundColor Green
Write-Host ("  CAI DAT THANH CONG DPS AUTO HELPER! [" + $copied + " files]") -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "CAC BUOC TIEP THEO:" -ForegroundColor Yellow
Write-Host "  1. Mo game DPS Desktop Pension Squad tren Steam."
Write-Host "  2. Mo trinh duyet va truy cap link giao dien sau de dieu khien:"
Write-Host "     https://titlee2111.github.io/dps-auto-helper/" -ForegroundColor Cyan
Write-Host "  3. Phim tat trong game: F6 (Tu Dong Cat Do), F7 (Tu Dong Hop Thanh)."
Write-Host ""

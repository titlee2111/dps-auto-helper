﻿<#
  DPS Auto Helper - 1-Click Installer
#>
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $root "payload"

if (-not (Test-Path $payload)) {
    Write-Host "[LỖI] Không tìm thấy thư mục payload! Hãy giải nén toàn bộ file zip trước." -ForegroundColor Red
    exit 1
}

function Test-GameFolder([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $false }
    return (Test-Path (Join-Path $path "DPS.exe")) -and (Test-Path (Join-Path $path "GameAssembly.dll"))
}

function Find-SteamLibraries {
    $libraries = New-Object System.Collections.Generic.List[string]
    $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { $steam = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -ErrorAction SilentlyContinue).InstallPath }

    if ($steam -and (Test-Path $steam)) {
        $libraries.Add($steam)
        $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($line in Get-Content $vdf) {
                if ($line -match '"path"\s+"([^"]+)"') {
                    $cand = $matches[1] -replace '\\\\', '\'
                    if (Test-Path $cand) { $libraries.Add($cand) }
                }
            }
        }
    }
    return $libraries | Select-Object -Unique
}

function Find-Game {
    if (Test-GameFolder $root) { return $root }
    # Parent dir check
    $parent = Split-Path -Parent $root
    if (Test-GameFolder $parent) { return $parent }

    foreach ($library in Find-SteamLibraries) {
        $candidate = Join-Path $library "steamapps\common\DPS Desktop Pension Squad"
        if (Test-GameFolder $candidate) { return $candidate }
    }
    return $null
}

$GamePath = Find-Game
if (-not $GamePath) {
    Write-Host "[!] Không tìm thấy thư mục cài game tự động." -ForegroundColor Yellow
    $GamePath = Read-Host "Vui lòng dán đường dẫn thư mục chứa DPS.exe vào đây"
    if (-not (Test-GameFolder $GamePath)) {
        Write-Host "[LỖI] Thư mục không hợp lệ! Không tìm thấy DPS.exe và GameAssembly.dll." -ForegroundColor Red
        exit 1
    }
}

Write-Host "[+] Đã tìm thấy game tại: " -NoNewline
Write-Host "$GamePath" -ForegroundColor Cyan

# Kiểm tra nếu game đang bật
$running = Get-Process "DPS" -ErrorAction SilentlyContinue
if ($running) {
    Write-Host "[!] Phát hiện game DPS đang chạy. Đang đóng game để cập nhật file..." -ForegroundColor Yellow
    Stop-Process -Name "DPS" -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
}

# Sao chép payload
Write-Host "[+] Đang cài đặt các file mod hỗ trợ vào game..." -ForegroundColor Green
$copied = 0
function Copy-Tree([string]$src, [string]$dst) {
    if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst -Force | Out-Null }
    foreach ($item in Get-ChildItem $src -Force) {
        $target = Join-Path $dst $item.Name
        if ($item.PSIsContainer) {
            Copy-Tree $item.FullName $target
        } else {
            Copy-Item $item.FullName $target -Force
            $script:copied++
        }
    }
}

Copy-Tree $payload $GamePath

Write-Host "============================================================" -ForegroundColor Green
Write-Host ("  CÀI ĐẶT THÀNH CÔNG DPS AUTO HELPER! [" + $copied + " files]") -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "CÁC BƯỚC TIẾP THEO:" -ForegroundColor Yellow
Write-Host "  1. Mở game DPS Desktop Pension Squad bình thường trên Steam."
Write-Host "  2. Mở trang web điều khiển để Bật/Tắt Tự động Cất Đồ (F6) & Tự động Hợp Thành (F7)."
Write-Host ""

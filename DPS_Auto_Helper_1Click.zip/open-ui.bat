@echo off
setlocal
cd /d "%~dp0"

rem Opens the browser control panel. Each running game instance listens on its own port in
rem 47900..47919, so every port that answers gets its own tab.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$found = 0;" ^
  "foreach ($port in 47900..47919) {" ^
  "  try {" ^
  "    $r = Invoke-WebRequest ('http://127.0.0.1:' + $port + '/status') -TimeoutSec 1 -UseBasicParsing;" ^
  "    if ($r.Content -match '""pid"":(\d+)') { $found++; Write-Host ('port ' + $port + '  pid ' + $matches[1]) -ForegroundColor Green; Start-Process ('http://127.0.0.1:' + $port + '/') }" ^
  "  } catch { }" ^
  "}" ^
  "if ($found -eq 0) { Write-Host 'no trainer answered - is the game running?' -ForegroundColor Yellow }"

if %errorlevel% neq 0 pause

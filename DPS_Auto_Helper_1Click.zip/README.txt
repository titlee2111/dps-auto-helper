DPS Trainer — build b8df42a2
============================

What this is
------------
BepInEx IL2CPP mod plus a browser control panel for DPS Desktop Pension Squad.

  god mode            incoming damage on the player is refused, live HP kept
  damage multiplier   applied at DamageSpec.FactorAt
  attack speed        applied through the AttackSpeed stat node
  auto-open boxes     normal / stage / elite boxes open the moment stock changes
  DLC unlock          all six packs answer "owned" client-side
  detector shield     the three integrity probes are neutralised

Control is a web page served by the mod itself: sliders, number fields, checkboxes.
No console commands.


Install
-------
1. Unpack this folder anywhere (not necessarily inside the game).
2. Double-click install.bat
   - it finds the game through Steam automatically
   - or pass the folder:  install.bat "D:\SteamLibrary\steamapps\common\DPS Desktop Pension Squad"
3. Start the game.
4. Double-click open-ui.bat, or open the address printed in BepInEx\LogOutput.log.


The browser panel
-----------------
Each running instance of the game listens on its own port: 47900, 47901, ... in start order.
open-ui.bat probes 47900-47919 and opens a tab for every instance that answers, so two
accounts get two tabs.

  Damage multiplier   1 .. 1000, any decimal  (7.25 is fine)
  Attack speed        1 .. 20,   any decimal
  Apply to game       pushes every field at once
  Read from game      pulls current values back
  Panic reset         damage 1x, speed 1x, god off, auto off, dlc off, shield on


Hotkeys (in game only)
----------------------
  F1   god mode
  F2   detector shield
  F3   auto-open boxes
  F5   DLC unlock
  F12  panic


Files it adds
-------------
  winhttp.dll                  Doorstop proxy, loads BepInEx before the game starts
  doorstop_config.ini          which assembly to load
  .doorstop_version            doorstop state file
  dotnet\                      private CoreCLR 6.0 runtime for the mod host
  BepInEx\core\                BepInEx loader
  BepInEx\interop\             generated IL2CPP wrappers for THIS build
  BepInEx\unity-libs\          Unity reference assemblies, used if interop is regenerated
  BepInEx\plugins\DPS.Trainer.dll
  BepInEx\config\BepInEx.cfg   console window off, file log on
  BepInEx\config\ofx.dps.trainer.cfg

No original game file is modified. remove.bat deletes exactly this list.


Build compatibility
-------------------
Everything is resolved by class and method name at runtime, never by a fixed address, so a
game update that only shifts code does not break the trainer. The one thing tied to the build
is BepInEx\interop: it is generated from that build's metadata.

  same build (GameAssembly.dll sha256 starts 2a612da2...)
      works immediately, offline.

  different build
      install with -Slim, or delete BepInEx\interop before starting the game. BepInEx then
      regenerates the wrappers from the local build; unity-libs is already here, so no
      download is needed. It takes a couple of minutes the first time.


If something looks wrong
------------------------
  BepInEx\LogOutput.log        everything the mod did, including resolver lines

  no panel / no link
      the game must be running; check the log for  [ipc] control panel http://127.0.0.1:...

  two accounts, one tab only
      both instances answer, but a single copy of the game cannot start twice (the build has
      single-instance set). Use a second copy of the game folder, or run the second account
      in a sandbox - each instance picks its own port.


Uninstall
---------
Drag the game folder onto remove.bat, or:
  remove.bat "C:\path\to\game"

@echo off
chcp 65001 >nul
title Cài Đặt DPS Auto Helper (1-Click)
cls
echo ============================================================
echo   DPS AUTO HELPER - CÀI ĐẶT 1-CLICK TỰ ĐỘNG
echo ============================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
pause

@echo off
setlocal
cd /d "%~dp0"

rem Removes only the files the trainer added. Game files are untouched.

set "TARGET=%~1"
if "%TARGET%"=="" (
    echo Drag the game folder onto this file, or run: remove.bat "C:\path\to\game"
    pause
    exit /b 1
)

if not exist "%TARGET%\DPS.exe" (
    echo not a DPS install: %TARGET%
    pause
    exit /b 1
)

echo removing from %TARGET%
if exist "%TARGET%\BepInEx" rmdir /s /q "%TARGET%\BepInEx"
if exist "%TARGET%\dotnet" rmdir /s /q "%TARGET%\dotnet"
if exist "%TARGET%\winhttp.dll" del /q "%TARGET%\winhttp.dll"
if exist "%TARGET%\doorstop_config.ini" del /q "%TARGET%\doorstop_config.ini"
if exist "%TARGET%\.doorstop_version" del /q "%TARGET%\.doorstop_version"
echo done - game files are as they were.
pause
